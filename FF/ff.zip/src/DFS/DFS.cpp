#include "DFS.hpp"

using namespace std;

/*
███████╗██╗   ██╗███╗   ██╗ ██████╗ ██████╗ ███████╗███████╗
██╔════╝██║   ██║████╗  ██║██╔════╝██╔═══██╗██╔════╝██╔════╝
█████╗  ██║   ██║██╔██╗ ██║██║     ██║   ██║█████╗  ███████╗
██╔══╝  ██║   ██║██║╚██╗██║██║     ██║   ██║██╔══╝  ╚════██║
██║     ╚██████╔╝██║ ╚████║╚██████╗╚██████╔╝███████╗███████║
╚═╝      ╚═════╝ ╚═╝  ╚═══╝ ╚═════╝ ╚═════╝ ╚══════╝╚══════╝
*/

void printFinal(vector<int> ordemVisitacao){
    for (int i = 0; i < static_cast<int>(ordemVisitacao.size()); i++){
        cout << ordemVisitacao[i] << "\n";
    }
}

/*
 █████╗ ██████╗ ███████╗███████╗████████╗ █████╗ 
██╔══██╗██╔══██╗██╔════╝██╔════╝╚══██╔══╝██╔══██╗
███████║██████╔╝█████╗  ███████╗   ██║   ███████║
██╔══██║██╔══██╗██╔══╝  ╚════██║   ██║   ██╔══██║
██║  ██║██║  ██║███████╗███████║   ██║   ██║  ██║
╚═╝  ╚═╝╚═╝  ╚═╝╚══════╝╚══════╝   ╚═╝   ╚═╝  ╚═╝
*/

Aresta::Aresta(int id, int origem, int destino, double peso, bool visitado, bool usavel){
    this->id = id;
    this->origem = origem;
    this->destino = destino;
    this->peso = peso;
    this->visitado = visitado;
    this->usavel = usavel;
}
Aresta::~Aresta(){}

void Aresta::printInfo(){
    cout << "--------- Aresta ---------\n";
    cout << "Id         : " << this->id << "\n" ;
    cout << "Origem     : " << this->origem << "\n" ;
    cout << "Destino    : " << this->destino << "\n" ;
    cout << "Peso       : " << this->peso << "\n" ;
    cout << "Visitado   : " << this->visitado << "\n" ;
    cout << "Usavel     : " << this->usavel << "\n\n" ;
}

/*
██╗   ██╗███████╗██████╗ ████████╗██╗ ██████╗███████╗
██║   ██║██╔════╝██╔══██╗╚══██╔══╝██║██╔════╝██╔════╝
██║   ██║█████╗  ██████╔╝   ██║   ██║██║     █████╗  
╚██╗ ██╔╝██╔══╝  ██╔══██╗   ██║   ██║██║     ██╔══╝  
 ╚████╔╝ ███████╗██║  ██║   ██║   ██║╚██████╗███████╗
  ╚═══╝  ╚══════╝╚═╝  ╚═╝   ╚═╝   ╚═╝ ╚═════╝╚══════╝
*/

Vertice::Vertice(int id, bool visitado){
    this->id = id;
    this->visitado = visitado;
}
Vertice::~Vertice(){}

void Vertice::printInfo(){
    cout << "--------- Vertice ---------\n";
    cout << "Id                            : " << this->id << "\n" ;
    cout << "Visitado                      : " << this->visitado << "\n" ;
    cout << "Tamanho da lista de adjacencia: " << this->adjacencia.size() << "\n\n" ;
}

/*
 ██████╗ ██████╗  █████╗ ███████╗ ██████╗ 
██╔════╝ ██╔══██╗██╔══██╗██╔════╝██╔═══██╗
██║  ███╗██████╔╝███████║█████╗  ██║   ██║
██║   ██║██╔══██╗██╔══██║██╔══╝  ██║   ██║
╚██████╔╝██║  ██║██║  ██║██║     ╚██████╔╝
 ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝      ╚═════╝ 
*/

Grafo::Grafo(){}
Grafo::Grafo(int qntd_vertices, int qntd_arestas, int vertice_inicial):qntd_vertices(qntd_vertices), qntd_arestas(qntd_arestas), vertice_inicial(vertice_inicial){}
Grafo::~Grafo(){}

void Grafo::inicializaGrafo(){

    // Leitura dos dados iniciais
    int aux; // retirar
    int qntd_vertices, qntd_arestas, vertice_inicial;

    cin >> qntd_vertices >> qntd_arestas >> aux >> vertice_inicial;

    this->qntd_arestas = qntd_arestas;
    this->qntd_vertices = qntd_vertices;
    this->vertice_inicial = vertice_inicial;

    // Lendo vertices
    for (int i = 1; i <= this->qntd_vertices; i++){
        Vertice v(i, false);
        this->vertices.push_back(v);;
    }

    // Lendo arestas e criando listas de adjacencia
    int origem, destino;
    double peso;

    for (int i = 1; i <= this->qntd_arestas; i++){
        cin >> origem >> destino >> peso;
        
        Aresta a = Aresta(i, origem, destino, peso, false, true);
        this->arestas.push_back(a);

        this->vertices[origem - 1].adjacencia.push_back(i);
    }
}

vector<int> Grafo::DFS(int vertice_inicial, vector<int>* ordem_visitacao){
    
    this->vertices[vertice_inicial - 1].visitado = true;
    ordem_visitacao->push_back(vertice_inicial);

    for (auto i : this->vertices[vertice_inicial - 1].adjacencia){
        // if (!(this->matriz[vertice_inicial - 1][i].status)){
        //     continue;
        // }

        // cout << this->arestas[i-1].destino << endl;
        int vertice_atual = this->arestas[i - 1].destino;

        if (this->vertices[vertice_atual - 1].visitado){
            if (!(this->arestas[i - 1].visitado)){
                this->arestas[i - 1].visitado = true;
            }
        }
        else{
            this->arestas[i - 1].visitado = true;
            this->DFS(vertice_atual, ordem_visitacao);
        }
    }

    return *ordem_visitacao;
}

void Grafo::printInfo(){
    cout << "--------- Grafo ---------\n";
    cout << "Qntd vertices  : " << this->qntd_vertices << "\n" ;
    cout << "Qntd arestas   : " << this->qntd_arestas << "\n" ;
    cout << "Vertice inicial: " << this->vertice_inicial << "\n\n" ;
}